// ...


const greeting = createGreeting('Joe Blow');

console.log(greeting);

/* 
 * Expected output:
 * Hello Joe Blow!
 */