const student = {
	name: "Joe Blow",
	age: 25,
	country: "Canada"
};

// ...

console.log(name);
console.log(age);

/*
 * Expected output:
 * Joe Blow
 * 25
 */